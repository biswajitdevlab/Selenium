I have created this project for facebook login function only.
i implemented pom and extent report along with maintained neat and clean code in this project.
     